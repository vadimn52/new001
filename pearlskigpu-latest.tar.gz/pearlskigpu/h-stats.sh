#!/bin/bash

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)

if [[ -z "$MINER_DIR" || -z "$CUSTOM_MINER" ]]; then
    MINER_PATH="$SCRIPT_DIR"
else
    MINER_PATH="$MINER_DIR/$CUSTOM_MINER"
fi

. "$MINER_PATH/h-manifest.conf"

log_basename="/var/log/miner/custom/custom"
log_name="$log_basename.log"
custom_version=v0.2.0

get_miner_version() {
    echo "$custom_version"
}

find_log_file() {
    local file legacy_file legacy_age now legacy_time

    for file in \
        "${CUSTOM_LOG_BASENAME}.log" \
        "/var/log/miner/custom/custom.log" \
        "$log_name"; do
        [[ -f "$file" ]] || continue
        echo "$file"
        return
    done

    legacy_file="/var/log/miner/custom/pearlskigpu.log"
    if [[ -f "$legacy_file" ]]; then
        now=$(date +%s)
        legacy_time=$(stat -c %Y "$legacy_file" 2>/dev/null || echo 0)
        legacy_age=$((now - legacy_time))
        if [[ "$legacy_age" -le 300 ]]; then
            echo "$legacy_file"
        fi
    fi
}

collect_log_tail() {
    [[ -f "$LOG_FILE" ]] || return
    tail -n 300 "$LOG_FILE" 2>/dev/null | tr '\r' '\n' | awk '{gsub(/\033\[[0-9;?]*[ -\/]*[@-~]/, ""); print}'
}

hash_to_hs() {
    local value="$1"
    local unit
    unit=$(echo "$2" | tr '[:upper:]' '[:lower:]' | sed 's#/#/#g')

    awk -v value="$value" -v unit="$unit" '
        BEGIN {
            factor = 1
            if (unit == "kh/s") factor = 1000
            else if (unit == "mh/s") factor = 1000000
            else if (unit == "gh/s") factor = 1000000000
            else if (unit == "th/s") factor = 1000000000000
            else if (unit == "ph/s") factor = 1000000000000000
            printf "%.0f", value * factor
        }'
}

hs_to_khs() {
    awk -v hs="$1" 'BEGIN {printf "%.0f", hs / 1000}'
}

uptime_to_seconds() {
    local text="$1"
    local total=0
    local item number unit

    for item in $(echo "$text" | grep -oE '[0-9]+[dhms]'); do
        number=${item%?}
        unit=${item: -1}
        case "$unit" in
            d) total=$((total + number * 86400)) ;;
            h) total=$((total + number * 3600)) ;;
            m) total=$((total + number * 60)) ;;
            s) total=$((total + number)) ;;
        esac
    done

    echo "$total"
}

get_miner_uptime() {
    local start_file="$MINER_PATH/miner_start_time"
    local pid_file="$MINER_PATH/miner.pid"
    local start now pid

    [[ -f "$start_file" ]] || return
    start=$(cat "$start_file" 2>/dev/null)
    [[ "$start" =~ ^[0-9]+$ ]] || return

    if [[ -f "$pid_file" ]]; then
        pid=$(cat "$pid_file" 2>/dev/null)
        if [[ "$pid" =~ ^[0-9]+$ ]] && ! kill -0 "$pid" 2>/dev/null; then
            return
        fi
    fi

    now=$(date +%s)
    [[ "$now" -ge "$start" ]] || return
    echo $((now - start))
}

read_hive_gpu_stats() {
    [[ -n "$GPU_STATS_JSON" ]] || return

    if [[ -f "$GPU_STATS_JSON" ]]; then
        cat "$GPU_STATS_JSON" 2>/dev/null
    else
        printf '%s' "$GPU_STATS_JSON"
    fi
}

bus_to_decimal() {
    local busid="$1"
    local bus_hex

    bus_hex=$(echo "$busid" | sed -n -E \
        -e 's/^([0-9A-Fa-f]{2}):[0-9A-Fa-f]{2}\..*/\1/p' \
        -e 's/^.*:([0-9A-Fa-f]{2}):[0-9A-Fa-f]{2}\..*/\1/p' |
        head -1)

    if [[ "$bus_hex" =~ ^[0-9A-Fa-f]+$ ]]; then
        echo $((16#$bus_hex))
    fi
}

selected_gpu_indexes() {
    local input="$1"
    local line values args gpu_arg gpu_stats_json

    line=$(echo "$input" | grep -Ei 'GPUs:[[:space:]]*[0-9,]+' | tail -1)
    values=$(echo "$line" | sed -n -E 's/.*GPUs:[[:space:]]*([0-9,]+).*/\1/p')

    if [[ -n "$values" ]]; then
        echo "$values" | tr ',' '\n' | grep -E '^[0-9]+$'
        return
    fi

    args=$(cat "$MINER_PATH/miner_args.txt" 2>/dev/null)
    gpu_arg=$(echo "$args" | sed -n -E 's/.*--gpus[[:space:]]+([^[:space:]]+).*/\1/p')
    if [[ "$gpu_arg" =~ ^[0-9]+(,[0-9]+)*$ ]]; then
        echo "$gpu_arg" | tr ',' '\n'
        return
    fi

    gpu_stats_json=$(read_hive_gpu_stats)
    if [[ -n "$gpu_stats_json" ]] && command -v jq >/dev/null 2>&1; then
        echo "$gpu_stats_json" | jq -r '
            [range(0; ((.busids // []) | length)) as $i |
                select((((.brand // []) | length) == 0) or ((.brand[$i] // "") == "nvidia"))] |
            to_entries[]?.key
        ' 2>/dev/null | grep -E '^[0-9]+$' && return
    fi

    if command -v nvidia-smi >/dev/null 2>&1; then
        nvidia-smi --query-gpu=index --format=csv,noheader,nounits 2>/dev/null | grep -E '^[0-9]+$'
    fi
}

load_gpu_arrays() {
    local input="$1"
    local -a indexes parsed_indexes hs temp fan bus
    local total_hs="$2"
    local per_gpu count idx i nvidia_temp nvidia_fan nvidia_bus bus_dec total_only
    local gpu_summary gpu_entry gpu_idx gpu_value gpu_unit parsed_count
    local gpu_khs gpu_stats_json

    mapfile -t indexes < <(selected_gpu_indexes "$input")
    count=${#indexes[@]}
    [[ "$count" -le 0 ]] && count=1 && indexes=(0)

    per_gpu=$(awk -v total="$total_hs" -v count="$count" 'BEGIN { if (count > 0) printf "%.0f", total / count; else print total }')

    gpu_summary=$(echo "$input" | grep -Ei 'GPU\[[0-9]+\][[:space:]]+[0-9]+(\.[0-9]+)?[[:space:]]*[kmgtp]?h/s' | tail -1)
    parsed_count=0

    while IFS= read -r gpu_entry; do
        [[ -n "$gpu_entry" ]] || continue
        gpu_idx=$(echo "$gpu_entry" | sed -n -E 's/.*GPU\[([0-9]+)\].*/\1/p')
        read -r gpu_value gpu_unit < <(
            echo "$gpu_entry" |
                sed -n -E 's/.*GPU\[[0-9]+\][[:space:]]+([0-9]+(\.[0-9]+)?)[[:space:]]*([kmgtpKMGTPhH]?\/?[hH]\/?[sS]|[kmgtpKMGTPhH]+\/[sS]).*/\1 \3/p' |
                sed -E 's#^([0-9.]+)[[:space:]]*([kmgtpKMGTPhH])/?[hH]?/?[sS]$#\1 \2h/s#I'
        )

        if [[ "$gpu_idx" =~ ^[0-9]+$ && -n "$gpu_value" && -n "$gpu_unit" ]]; then
            hs[$gpu_idx]=$(hash_to_hs "$gpu_value" "$gpu_unit")
            parsed_indexes+=("$gpu_idx")
            (( gpu_idx + 1 > parsed_count )) && parsed_count=$((gpu_idx + 1))
        fi
    done < <(echo "$gpu_summary" | grep -oEi 'GPU\[[0-9]+\][[:space:]]+[0-9]+(\.[0-9]+)?[[:space:]]*[kmgtp]?h/s')

    total_only=0
    if [[ "${synthetic_gpu0:-0}" -eq 1 ]]; then
        count=${#indexes[@]}
        [[ "$count" -le 0 ]] && count=1 && indexes=(0)
        total_only=1
    elif [[ "${#parsed_indexes[@]}" -gt 0 ]]; then
        indexes=("${parsed_indexes[@]}")
        count=${#indexes[@]}
    else
        # Total-only GPU logs are single-device miner output. Build the same
        # card list HiveOS sees, but put the total rate on the first card only.
        count=${#indexes[@]}
        [[ "$count" -le 0 ]] && count=1 && indexes=(0)
        per_gpu="$total_hs"
        total_only=1
    fi

    gpu_stats_json=$(read_hive_gpu_stats)
    if [[ -n "$gpu_stats_json" ]] && command -v jq >/dev/null 2>&1; then
        mapfile -t nvidia_temp < <(echo "$gpu_stats_json" | jq -r '
            range(0; ((.busids // []) | length)) as $i |
            select((((.brand // []) | length) == 0) or ((.brand[$i] // "") == "nvidia")) |
            (.temp[$i] // empty)
        ' 2>/dev/null)
        mapfile -t nvidia_fan < <(echo "$gpu_stats_json" | jq -r '
            range(0; ((.busids // []) | length)) as $i |
            select((((.brand // []) | length) == 0) or ((.brand[$i] // "") == "nvidia")) |
            (.fan[$i] // empty)
        ' 2>/dev/null)
        mapfile -t nvidia_bus < <(echo "$gpu_stats_json" | jq -r '
            range(0; ((.busids // []) | length)) as $i |
            select((((.brand // []) | length) == 0) or ((.brand[$i] // "") == "nvidia")) |
            (.busids[$i] // empty)
        ' 2>/dev/null)
    fi

    if [[ "${#nvidia_bus[@]}" -eq 0 ]] && command -v nvidia-smi >/dev/null 2>&1; then
        mapfile -t nvidia_temp < <(nvidia-smi --query-gpu=temperature.gpu --format=csv,noheader,nounits 2>/dev/null)
        mapfile -t nvidia_fan < <(nvidia-smi --query-gpu=fan.speed --format=csv,noheader,nounits 2>/dev/null)
        mapfile -t nvidia_bus < <(nvidia-smi --query-gpu=pci.bus_id --format=csv,noheader 2>/dev/null)
    fi

    for ((i=0; i<count; i++)); do
        idx=${indexes[$i]}
        if [[ "$total_only" -eq 1 ]]; then
            if [[ "$i" -eq 0 ]]; then
                hs[$i]="$total_hs"
            else
                hs[$i]=0
            fi
        else
            hs[$i]="${hs[$idx]:-${hs[$i]:-$per_gpu}}"
        fi
        temp[$i]="${nvidia_temp[$idx]:-null}"
        fan[$i]="${nvidia_fan[$idx]:-null}"
        [[ "${temp[$i]}" =~ ^[0-9]+$ ]] || temp[$i]="null"
        [[ "${fan[$i]}" =~ ^[0-9]+$ ]] || fan[$i]="null"

        if [[ -n "${nvidia_bus[$idx]}" ]]; then
            bus_dec=$(bus_to_decimal "${nvidia_bus[$idx]}")
            if [[ "$bus_dec" =~ ^[0-9]+$ ]]; then
                bus[$i]="$bus_dec"
            else
                bus[$i]="$idx"
            fi
        else
            bus[$i]="$idx"
        fi
    done

    khs_array="["
    hs_array="["
    temp_array="["
    fan_array="["
    bus_array="["

    for ((i=0; i<count; i++)); do
        [[ $i -gt 0 ]] && khs_array+="," && hs_array+="," && temp_array+="," && fan_array+="," && bus_array+=","
        gpu_khs=$(hs_to_khs "${hs[$i]}")
        khs_array+="$gpu_khs"
        hs_array+="$gpu_khs"
        temp_array+="${temp[$i]}"
        fan_array+="${fan[$i]}"
        bus_array+="${bus[$i]}"
    done

    khs_array+="]"
    hs_array+="]"
    temp_array+="]"
    fan_array+="]"
    bus_array+="]"

    parsed_gpu_total_hs=0
    gpu_total_only="$total_only"
    if [[ "${#parsed_indexes[@]}" -gt 0 ]]; then
        for ((i=0; i<count; i++)); do
            parsed_gpu_total_hs=$(awk -v a="$parsed_gpu_total_hs" -v b="${hs[$i]}" 'BEGIN {printf "%.0f", a + b}')
        done
    fi
}

build_stats() {
    local total_hs="$1"
    local uptime="$2"
    local ac="$3"
    local rj="$4"
    local ver
    ver=$(get_miner_version)

    load_gpu_arrays "$LOG_TAIL" "$total_hs"
    if [[ "$total_hs" -le 0 && "$parsed_gpu_total_hs" -gt 0 ]]; then
        total_hs="$parsed_gpu_total_hs"
    fi
    khs=$(awk -v hs="$total_hs" 'BEGIN {printf "%.0f", hs / 1000}')

    stats="{\"hs\":$hs_array,\"hs_units\":\"khs\",\"temp\":$temp_array,\"fan\":$fan_array,\"uptime\":$uptime,\"ver\":\"$ver\",\"ar\":[$ac,$rj],\"algo\":\"pearl\",\"bus_numbers\":$bus_array}"
}

emit_stats() {
    [[ -z "$khs" ]] && khs=0
    [[ -z "$stats" ]] && stats=""

    echo "$khs"
    echo "$stats"
}

LOG_FILE=$(find_log_file)
LOG_TAIL=$(collect_log_tail)

if [[ -z "$LOG_TAIL" ]]; then
    LOG_TAIL=""
    empty_uptime=$(get_miner_uptime)
    [[ "$empty_uptime" =~ ^[0-9]+$ ]] || empty_uptime=0
    build_stats 0 "$empty_uptime" 0 0
    emit_stats
    return 0 2>/dev/null || exit 0
fi

summary_line=$(echo "$LOG_TAIL" | grep -Ei '[0-9]+(\.[0-9]+)?[[:space:]]*[kmgtp]?h/s[[:space:]]*\|[[:space:]]*A:[0-9]+[[:space:]]+R:[0-9]+' | tail -1)
read -r total_value total_unit < <(
    echo "$summary_line" |
        grep -oEi '[0-9]+(\.[0-9]+)?[[:space:]]*[kmgtp]?h/s' |
        head -1 |
        sed -E 's#^([0-9.]+)[[:space:]]*([kmgtpKMGTPhH])/?[hH]?/?[sS]$#\1 \2h/s#I'
)

if [[ -n "$total_value" && -n "$total_unit" ]]; then
    total_hs=$(hash_to_hs "$total_value" "$total_unit")
else
    total_hs=0
fi

synthetic_gpu0=0
if [[ -n "$summary_line" && -n "$total_value" && -n "$total_unit" ]] &&
    ! echo "$summary_line" | grep -Eq 'GPU\[[0-9]+\]'; then
    synthetic_gpu0=1
    LOG_TAIL=$(printf '%s\n%s | GPU[0] %s %s\n' "$LOG_TAIL" "$summary_line" "$total_value" "$total_unit")
fi

ac=$(echo "$summary_line" | sed -n -E 's/.*A:([0-9]+)[[:space:]]+R:([0-9]+).*/\1/p')
rj=$(echo "$summary_line" | sed -n -E 's/.*A:([0-9]+)[[:space:]]+R:([0-9]+).*/\2/p')
[[ "$ac" =~ ^[0-9]+$ ]] || ac=0
[[ "$rj" =~ ^[0-9]+$ ]] || rj=0

uptime_text=$(echo "$summary_line" | sed -n -E 's/.*Up:[[:space:]]*([^|]+).*/\1/p')
uptime=$(uptime_to_seconds "$uptime_text")
miner_uptime=$(get_miner_uptime)
[[ "$miner_uptime" =~ ^[0-9]+$ ]] && uptime="$miner_uptime"

build_stats "$total_hs" "$uptime" "$ac" "$rj"
emit_stats
