#!/usr/bin/env bash

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)

if [[ -z "$MINER_DIR" || -z "$CUSTOM_MINER" ]]; then
    MINER_PATH="$SCRIPT_DIR"
else
    MINER_PATH="$MINER_DIR/$CUSTOM_MINER"
fi

. "$MINER_PATH/h-manifest.conf"

MINER_ARGS=$(cat "$MINER_PATH/miner_args.txt" 2>/dev/null)

if [[ -z "$MINER_ARGS" ]]; then
    echo -e "${RED}No miner arguments found. Run h-config.sh first.${NOCOLOR}"
    exit 1
fi

cd "$MINER_PATH" || exit 1
export CUDA_DEVICE_ORDER=PCI_BUS_ID

LOG_FILE="${CUSTOM_LOG_BASENAME}.log"
START_FILE="$MINER_PATH/miner_start_time"
PID_FILE="$MINER_PATH/miner.pid"
mkdir -p "$(dirname "$LOG_FILE")"
rm -f /var/log/miner/custom/pearlskigpu.log
: > "$LOG_FILE"
date +%s > "$START_FILE"

./pearlski-gpu-miner $MINER_ARGS > >(tee "$LOG_FILE") 2>&1 &
MINER_PID=$!
echo "$MINER_PID" > "$PID_FILE"

cleanup() {
    kill "$MINER_PID" 2>/dev/null
    wait "$MINER_PID" 2>/dev/null
    rm -f "$START_FILE" "$PID_FILE"
}

trap cleanup INT TERM EXIT

wait "$MINER_PID"
STATUS=$?
trap - INT TERM EXIT
exit "$STATUS"
